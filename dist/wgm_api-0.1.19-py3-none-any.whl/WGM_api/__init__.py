from WGM_api.wgm import WGM_api
